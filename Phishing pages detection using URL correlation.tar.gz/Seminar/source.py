import matplotlib.pyplot as plt

def diff_strings(s, t):
    if s == t: return 0
    elif len(s) == 0: return len(t)
    elif len(t) == 0: return len(s)
    v0 = [None] * (len(t) + 1)
    v1 = [None] * (len(t) + 1)
    for i in range(len(v0)):
        v0[i] = i
    for i in range(len(s)):
        v1[0] = i + 1
        for j in range(len(t)):
            cost = 0 if s[i] == t[j] else 1
            v1[j + 1] = min(v1[j] + 1, v0[j + 1] + 1, v0[j] + cost)
        for j in range(len(v0)):
            v0[j] = v1[j]
    return v1[len(t)]

def lcs(xstr, ystr):
    if not xstr or not ystr:
        return ""
    x, xs, y, ys = xstr[0], xstr[1:], ystr[0], ystr[1:]
    if x == y:
        return x + lcs(xs, ys)
    else:
        return max(lcs(xstr, ys), lcs(xs, ystr), key=len)

values = open("values.txt","w")
phi = open('phi1.txt')
dr = []
sr = []
for li in phi:
    t = li.strip() #phishing domain
    final_diff_rate = 1
    final_same_rate = 0
    f = open('sites_list.txt')
    a1 = " "
    for line in f:
        s = line.strip() #original domain
        len_s = float(len(s))

        diff = diff_strings(s,t)

        same = len(lcs(s,t))-2 #2 for "."

        diff = float(diff)
        diff_rate = round(diff/(len_s-2),2)

        same = float(same)
        same_rate = round(same/(len_s-2),2)

        if(final_diff_rate != min(diff_rate,final_diff_rate)):
            if(final_same_rate != max(same_rate,final_same_rate)):
                final_diff_rate = min(diff_rate,final_diff_rate)
                final_same_rate = max(same_rate,final_same_rate)
                a1 = s
    f.close()
    values.write(str(final_diff_rate))
    values.write(" ")
    values.write(str(final_same_rate))
    values.write(" ")
    if(final_diff_rate==0):
        values.write("NO")
    else:
        values.write("YES")
    values.write("\n")
    values.write(a1)

    a = 0.6
    b = 0.4

    dr.append(final_diff_rate)
    sr.append(final_same_rate)
    weight = a*final_diff_rate-b*final_same_rate

    if(final_diff_rate==0):
        print final_same_rate, final_diff_rate, weight, "NO", a1
    else:
        print final_same_rate, final_diff_rate, weight, "YES", a1
#plt.hist(dr, bins=[0.26,0.27,0.28,0.29,0.31,0.32,0.33,0.34,0.35,0.36,0.37], label = 'diff_rate')
#plt.hist(sr, bins=60, label ='same_rate')
phi.close()
plt.hist(dr, bins=[0.26,0.27,0.28,0.29,0.31,0.32,0.33,0.34,0.35,0.36,0.37], label = 'diff_rate')
plt.hist(sr, bins=60, label ='same_rate')
plt.xlabel('rate')
plt.ylabel('frequency')
plt.title('diff_rate')
plt.show()
values.close()
