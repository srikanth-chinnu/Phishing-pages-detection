s = raw_input().strip()
t = raw_input().strip()

def algorithm(s,t):
    if(len(s)==0):
        return len(t)
    elif(len(t)==0):
        return len(s)
    elif(s==t):
        return len(s),len(s)
    A = [0]*(len(t)+1)
    B = [0]*(len(t)+1)
    for i in range(len(A)):
        A[i] = i
    same = 0
    vari = -1
    for i in range(len(s)):
        B[0] = i+1
        for j in range(len(t)):
            if(s[i]==t[j]):
                cost = 0
            else:
                cost = 1
            B[j+1] = min(B[j]+1,A[j]+cost,A[j+1]+1)
            if(B[j+1] == A[j]+cost and vari!=j):
                same += 1
                vari = j
        for j in range(len(B)):
            A[j] = B[j]
    return B[len(B)-1],same
print algorithm(s,t)
